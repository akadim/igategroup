﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'lt', {
	block: 'Lygiuoti abi puses',
	center: 'Centruoti',
	left: 'Lygiuoti kairę',
	right: 'Lygiuoti dešinę'
} );
